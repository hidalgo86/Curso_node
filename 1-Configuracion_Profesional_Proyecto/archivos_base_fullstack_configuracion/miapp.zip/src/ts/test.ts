setTimeout(()=> {
    console.log("hola TypeScript");
}, 1000);
